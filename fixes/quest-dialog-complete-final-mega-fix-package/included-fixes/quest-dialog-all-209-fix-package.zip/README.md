# OSRS All 209 Quest Dialogue/State Fix

Target repo: `fuskeedk/ggwp-xrsps-server` / `ggwp-xrsps-server-main`

## What this package does

This package makes the server register all 209 OSRS reference quests:

- 72 hand-written/reference quests from the existing active packs.
- 137 generated playable quests from `generatedAutoQuests.ts`.
- Total active OSRS reference coverage: 209 / 209.

It also includes the quest/dialogue fixes from the previous package:

- Multiple quest handlers can coexist on the same NPC id without overwriting each other.
- Quest chains on the same NPC can continue after the previous quest is complete.
- Simple generated quests can start and finish on the same NPC.
- Quest completion is guarded against duplicate quest point/reward payout.
- Generated item turn-in journals use the correct helper argument order.
- Several bad/fuzzy generated progress ids were moved to unique varbit-backed state so quests do not complete each other.

## Important scope note

The 137 generated quests use playable generated dialogue, not full word-for-word official OSRS dialogue transcripts.

They include:

- start NPC id/name
- helper/step NPC id/name where available
- finish NPC id/name
- quest progress state
- basic start, progress, item turn-in and completion dialogue
- item requirements where the reference importer matched item ids

## Install

Copy the `server/` folder from this package into the project root and overwrite the matching files.

Changed files:

- `server/src/game/scripts/ScriptRegistry.ts`
- `server/src/game/scripts/ScriptRuntime.ts`
- `server/gamemodes/vanilla/quests/index.ts`
- `server/gamemodes/vanilla/quests/QuestService.ts`
- `server/gamemodes/vanilla/quests/definitions/questFactory.ts`
- `server/gamemodes/vanilla/quests/definitions/generatedAutoQuests.ts`
- `server/gamemodes/vanilla/quests/definitions/f2pRemainingQuests.ts`
- `server/gamemodes/vanilla/quests/definitions/membersQuestPack.ts`
- `server/gamemodes/vanilla/quests/definitions/additionalMembersQuests.ts`
- `server/gamemodes/vanilla/quests/definitions/membersQuestPack2.ts`
- `server/gamemodes/vanilla/quests/definitions/membersQuestPack3.ts`

## Expected QA result

After install, a static quest check should show:

- registered definitions: 209
- reference quests: 209
- missing reference quests: 0
- extra registered quests: 0
- duplicate quest names: 0
- duplicate progress state ids: 0

## Verify after copying

Run:

```bash
npm install
npm run server:build
```

Then test these high-risk NPC chains in-game:

- King Roald: Shield of Arrav -> Priest in Peril
- Drezel: Priest in Peril -> Nature Spirit
- King Narnode Shareen: The Grand Tree -> Monkey Madness I
- Kolodion: Mage Arena I -> Mage Arena II
- King Arthur: Merlin's Crystal -> Holy Grail
- Elena: Plague City -> Biohazard
- Trufitus: Jungle Potion -> Shilo Village
- Godric: Death Plateau -> Troll Stronghold
- Lucien: Temple of Ikov -> later Lucien quest use
- Edmond: Plague City -> Underground Pass alternate starter

# Quest Dialogue/State Fix Package

Target repo: `fuskeedk/ggwp-xrsps-server` / `ggwp-xrsps-server-main`

## What this fixes

This package fixes the main quest/dialogue blockers found in QA:

- NPC quest dialogue handlers no longer overwrite each other when multiple quests use the same NPC id.
- Simple quest stubs can now start and finish on the same NPC.
- Completed earlier quests in a quest chain no longer block the next quest on the same NPC.
- Quest completion cannot award quest points/rewards twice if called again.
- `autoQuest` item journal rendering uses the correct helper argument order.
- `Elemental Workshop II` no longer shares varp `273` with `Prince Ali Rescue`; it now uses varbit `2639`.
- Invalid quest dialogue usage of `event.npcId` was replaced with `event.npc.typeId`.

## Install

Copy the `server/` folder from this package into the project root and overwrite the matching files.

Changed files:

- `server/src/game/scripts/ScriptRegistry.ts`
- `server/src/game/scripts/ScriptRuntime.ts`
- `server/gamemodes/vanilla/quests/QuestService.ts`
- `server/gamemodes/vanilla/quests/definitions/questFactory.ts`
- `server/gamemodes/vanilla/quests/definitions/f2pRemainingQuests.ts`
- `server/gamemodes/vanilla/quests/definitions/membersQuestPack.ts`
- `server/gamemodes/vanilla/quests/definitions/additionalMembersQuests.ts`
- `server/gamemodes/vanilla/quests/definitions/membersQuestPack2.ts`
- `server/gamemodes/vanilla/quests/definitions/membersQuestPack3.ts`

## Verify after copying

Run:

```bash
npm install
npm run server:build
```

Then test in-game with these NPC/quest chains:

- King Roald: Shield of Arrav -> Priest in Peril
- Drezel: Priest in Peril -> Nature Spirit
- King Narnode Shareen: The Grand Tree -> Monkey Madness
- King Arthur: Merlin's Crystal -> Holy Grail
- Elena: Plague City -> Biohazard
- Trufitus: Jungle Potion -> Shilo Village
- Godric: Death Plateau -> Troll Stronghold
- Lucien: Temple of Ikov -> later Lucien use
- Edmond: Plague City -> Underground Pass alternate starter

## Known scope

This does not add full official OSRS dialogue for all 209 quests. The active server still registers 73 hand-written/stub quests. The generated 137 auto quests remain disabled in `server/gamemodes/vanilla/quests/index.ts` and should only be enabled after more QA.

The main technical blocker is fixed: multiple quest handlers can now coexist on one NPC id instead of overwriting each other.
